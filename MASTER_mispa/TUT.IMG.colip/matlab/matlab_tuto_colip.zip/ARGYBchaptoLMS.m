function LMS=ARGYBchaptoLMS(argyb_chap)
% conversion vers LMS

LMS = ARGYBtildetoLMS(ARGYBchaptoARGYBtilde(argyb_chap));

