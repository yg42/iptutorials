function M0 = getColipM0()
% fonction qui retourne la valeur de M0 utilisée partout.
M0 = 100;