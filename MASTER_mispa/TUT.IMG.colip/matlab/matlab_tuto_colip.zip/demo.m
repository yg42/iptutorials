% CoLIP - Color Logarithmic Image Processing
