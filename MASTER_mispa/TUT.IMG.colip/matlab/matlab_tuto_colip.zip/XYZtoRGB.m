function XYZ = XYZtoRGB(RGB)

% matrix CIE RGB illuminant E
% sum of elements is 1
U = 100*[0.4887180  0.3106803  0.2006017;  0.1762044  0.8129847  0.0108109; 0.0000000  0.0102048  0.9897952];

[M,N,~]=size(RGB); 
RGB=reshape(RGB,[M*N,3])';

XYZ=U\RGB; % inv(U)*LMS
XYZ=reshape(XYZ',[M,N,3]);