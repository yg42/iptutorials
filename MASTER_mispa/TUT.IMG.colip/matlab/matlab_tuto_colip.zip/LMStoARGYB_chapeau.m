function ARGYB_chap=LMStoARGYB_chapeau(LMS)
% LMS: valeurs normalisées entre ]0;M0]

ARGYBtilde = LMStoARGYBtilde(LMS);

% vérifications
% figure(); hold on
% for i=1:3
%     plot(ARGYBtilde(:,:,i));
% end

% conversion valeur absolue
ARGYB_chap = ARGYBtildetoARGYBchap(ARGYBtilde);
