function h = LBP(A)

[m,n] = size(A);

B = zeros(m,n);

code = [1 2 4; 8 0 16; 32 64 128];

parfor i=2:m-1
    for j=2:n-1
        w = A(i-1:i+1,j-1:j+1);
        w = (w >= A(i,j));
        w = w.*code;
        B(i,j) = sum(w(:));
    end
end

B = B(2:m-1,2:n-1);
[h,~] = imhist(B/255,256);
h = h/sum(h(:));