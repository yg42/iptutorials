%% SOLUTION TUTORIAL PDEs

%% 0 - Cleaning
clc; clear all; close all;

%% 1 - Linear diffusion

% reading image
I = imread('cerveau.bmp');
I = double(I)/255;

% linear diffusion process
dt = 0.05;
Ildiff10 = linearDiffusion(I,10,dt);
Ildiff50 = linearDiffusion(I,50,dt);

% visualization
figure
subplot(131);imshow(I);
subplot(132);imshow(Ildiff10);
subplot(133);imshow(Ildiff50);

%% 2 - Nonlinear diffusion

% nonlinear diffusion process
dt = 0.05;
Inldiff10 = nonlinearDiffusion(I,10,0.1,dt);
Inldiff100 = nonlinearDiffusion(I,100,0.1,dt);

% visualization
figure
subplot(131);imshow(I);
subplot(132);imshow(Inldiff10);
subplot(133);imshow(Inldiff100);

%% 3 - Degenerate diffusion

% morphological diffusion process
dt = 0.05;
[Ierodiff20,Idildiff20] = morphologicalDiffusion(I,20,dt);
[Ierodiff50,Idildiff50] = morphologicalDiffusion(I,50,dt);

% visualization
figure
subplot(231);imshow(I);
subplot(232);imshow(Idildiff20);
subplot(233);imshow(Idildiff50);
subplot(235);imshow(Ierodiff20);
subplot(236);imshow(Ierodiff50);

%% Useful functions

type linearDiffusion.m
type nonlinearDiffusion.m
type morphologicalDiffusion.m