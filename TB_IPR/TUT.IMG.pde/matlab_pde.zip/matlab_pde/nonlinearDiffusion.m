function Z = nonlinearDiffusion(I,nbIter,dt,alpha)

hW = [1 -1 0];
hE = [0 -1 1];
hN = hW';
hS = hE';

Z = I;

for i=1:nbIter
    % calculate gradient in all directions (N,S,E,W)
    gW = imfilter(Z,hW);
    gE = imfilter(Z,hE);
    gN = imfilter(Z,hN);
    gS = imfilter(Z,hS);
    
    % next Image
    Z = Z + dt*(c(abs(gN),alpha).*gN + c(abs(gS),alpha).*gS + c(abs(gW),alpha).*gW + c(abs(gE),alpha).*gE);
end

end

function Z = c(I,alpha)

Z = exp(-(I/alpha).^2);

end

