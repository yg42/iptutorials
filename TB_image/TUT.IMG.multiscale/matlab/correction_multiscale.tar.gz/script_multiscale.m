%% CORRECTION TP ANALYSE MULTI-ECHELLE - OPTION I&S

%% 0 - Nettoyage

clear all;close all;clc

%% 1 - D�composition et recomposition pyramidale

% d�composition 4 niveaux : 0, 1, 2 et 3
A=imread('cerveau.bmp');
A=double(A);
Adec0=A;
figure
subplot(4,2,1);viewImage(Adec0);title('image originale : 0');
[Adec1,R1]=decompose(Adec0);
[Adec2,R2]=decompose(Adec1);
[Adec3,R3]=decompose(Adec2);
subplot(4,2,3);viewImage(Adec1);title('decomposition : 1');
subplot(4,2,2);viewImage(R1);title('erreur : 0');
subplot(4,2,5);viewImage(Adec2);title('decomposition : 2');
subplot(4,2,4);viewImage(R2);title('erreur : 1');
subplot(4,2,7);viewImage(Adec3);title('decomposition : 3');
subplot(4,2,6);viewImage(R3);title('erreur : 2');

%% 2 - Recomposition pyramidale

% avec les d�tails
Arec2=recompose(Adec3,R3,255);
Arec1=recompose(Arec2,R2,255);
Arec0=recompose(Arec1,R1,255);
figure
subplot(142);viewImage(Arec2);title('recomposition : 2');
subplot(143);viewImage(Arec1);title('recomposition : 1');
subplot(144);viewImage(Arec0);title('recomposition : 0');
subplot(141);viewImage(A);title('image originale');
erreur=abs(A-Arec0);
mean(erreur(:))

% sans les d�tails
Arec2=recompose(Adec3,R3,-1);
Arec1=recompose(Arec2,R2,-1);
Arec0=recompose(Arec1,R1,-1);
figure
subplot(142);viewImage(Arec2);title('recomposition : 2');
subplot(143);viewImage(Arec1);title('recomposition : 1');
subplot(144);viewImage(Arec0);title('recomposition : 0');
subplot(141);viewImage(A);title('image originale');
erreur=abs(A-Arec0);
mean(erreur(:))

%% 3 - Filtage multi-�chelle

% d�composition scale-space
k=3;
ss=cell(2,k);
for i=1:k
    se = strel('disk',2*i);
    ss{1,i}=imdilate(A,se);
    ss{2,i}=imerode(A,se);
end
figure
subplot(241);viewImage(A);title('image originale');
subplot(242);viewImage(ss{1,1});title('dilatation : 1');
subplot(243);viewImage(ss{1,2});title('dilatation : 2');
subplot(244);viewImage(ss{1,3});title('dilatation : 3');

subplot(246);viewImage(ss{2,1});title('erosion : 1');
subplot(247);viewImage(ss{2,2});title('erosion : 2');
subplot(248);viewImage(ss{2,3});title('erosion : 3');

% KB

sskb=cell(1,k);
for i=1:k
   difbool=double((ss{1,i}-A)<(A-ss{2,i}));
   sskb{1,i}=ss{1,i}.*difbool+ss{2,i}.*(1-difbool); 
end

figure
subplot(242);viewImage(sskb{1,1});title('KB : 1');
subplot(243);viewImage(sskb{1,2});title('KB : 2');
subplot(244);viewImage(sskb{1,3});title('KB : 3');
subplot(241);viewImage(A);title('image originale');

% KB multi-�chelle
sskbm=cell(1,4);
sskbm{1,1}=sskb{1,1};
for i=2:k
    difbool=(sskb{1,i}>sskbm{1,i-1});
    sskbm{1,i}=sskb{1,i}.*difbool+sskbm{1,i-1}.*(1-difbool);
end
subplot(246);viewImage(sskbm{1,1});title('KBM : 1');
subplot(247);viewImage(sskbm{1,2});title('KBM : 2');
subplot(248);viewImage(sskbm{1,3});title('KBM : 3');

%% 4 - Fonctions annexes

readfile('decompose.m');
readfile('recompose.m');
readfile('viewImage.m');


