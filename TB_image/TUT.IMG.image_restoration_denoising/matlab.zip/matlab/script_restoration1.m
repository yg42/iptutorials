%% CORRECTION TP RESTAURATION 1 - OPTION I&S

%% 0 - Nettoyage

clear all;close all;clc

%% 1 - Generation de bruit al�atoire

% bruit uniforme
a=0;b=1;
R1=a+(b-a)*rand(500);R1=recadre(R1);
% bruit gaussien
b=45;
R2=a+b*randn(500);R2=recadre(R2);
% bruit poivre et sel
a=0.05;b=0.05;
R3(1:500,1:500)=0.5;
X=rand(500);
c=find(X<=a);R3(c)=0;
c=find(X>a & X<=a+b);R3(c)=1;R3=recadre(R3);
% bruit exponentiel
a=1;
R4=-1/a*log(1-rand(500));R4=recadre(R4);
figure;
subplot(2,2,1);viewImage(R1);title('bruit uniforme');
subplot(2,2,2);viewImage(R2);title('bruit gaussien');
subplot(2,2,3);viewImage(R3);title('bruit poivre et sel');
subplot(2,2,4);viewImage(R4);title('bruit exponentiel');
% histogrammes
figure;
subplot(2,2,1);imhist(R1);title('bruit uniforme');
subplot(2,2,2);imhist(R2,50);title('bruit gaussien');
subplot(2,2,3);imhist(R3);title('bruit poivre et sel');
subplot(2,2,4);imhist(R4);title('bruit exponentiel');

%% 2 - Estimation du type de bruit

A=imread('jambe.tif');
A=double(A);
A=A/255;
figure;
c=[160 200 200 160];
r=[200 200 240 240];
C=roipoly(A,c,r);
subplot(1,3,1);viewImage(A);title('image originale');
subplot(1,3,2);viewImage(C);title('ROI');
subplot(1,3,3);imhist(A(C));title('histogramme de la ROI');
% bruit exponentiel
[m,n]=size(A);
expnoise=1/0.5*log(1-rand(m,n));
B=A-expnoise/max(max(abs(expnoise)));B=recadre(B);
figure;
subplot(1,2,1);viewImage(B);title('image bruit�e (exponentiel)');
subplot(1,2,2);imhist(B(C));title('histogramme de la ROI');
% bruit gaussien
B=imnoise(A,'gaussian',0,0.004);
figure;
subplot(1,2,1);viewImage(B);title('image bruit�e (gaussien)');
subplot(1,2,2);imhist(B(C));title('histogramme de la ROI');

%% 3 - Filtrage spatial de restauration
% lecture et visualisation de l'image;
A=imread('jambe.tif');
A=double(A);
A=A/255;
[m,n]=size(A);
% ajout du bruit poivre et sel
B=imnoise(A,'salt & pepper', 0.25);
% filtrage de l'image bruit�e
% mean
w=fspecial('average',5);
B1=imfilter(B,w);
% max
B2=ordfilt2(B,9,ones(3,3));
% min
B3=ordfilt2(B,1,ones(3,3));
% median
B4=medfilt2(B,[7,7]);
%
figure
subplot(3,2,1);viewImage(A);title('image originale');
subplot(3,2,2);viewImage(B);title('image bruit�e');
subplot(3,2,3);viewImage(B1);title('filtrage moyen');
subplot(3,2,4);viewImage(B2);title('filtrage max');
subplot(3,2,5);viewImage(B3);title('filtrage min');
subplot(3,2,6);viewImage(B4);title('filtrage m�dian');
%filtage m�dian adaptatif
B5=appmedian(B,7);
figure
subplot(2,2,1);viewImage(A);title('image originale');
subplot(2,2,2);viewImage(B);title('image bruit�e');
subplot(2,2,3);viewImage(B4);title('filtrage m�dian');
subplot(2,2,4);viewImage(B5);title('filtrage m�dian adaptatif');

%% 4 - Fonctions annexes

readfile('appmedian.m');
readfile('recadre.m');
readfile('viewImage.m');